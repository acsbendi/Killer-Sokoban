package skeleton;

import model.*;

public class TestCase05 implements TestCase{
	@Override
	public void Test() {
		Logger.Init();
		Tile tile = new Tile();
        Logger.Register(tile);
        HoleTile holeTile = new HoleTile();
        Logger.Register(holeTile);
        Wall wall = new Wall();
        Logger.Register(wall);
        Worker worker = new Worker();
        Logger.Register(worker);
        
        Direction direction1 = Direction.Right;
        Logger.Register(direction1);

        Direction direction2 = direction1.Opposite();
        Logger.Register(direction2);

        tile.InitializeObject(worker);
        tile.SetNeighbour(direction1,holeTile);

        holeTile.SetNeighbour(direction2,tile);
        holeTile.SetNeighbour(direction1,wall);

        worker.Move(direction1);
	}

    @Override
    public String GetName() {
        return "Munkás lyukba lép";
    }
}
