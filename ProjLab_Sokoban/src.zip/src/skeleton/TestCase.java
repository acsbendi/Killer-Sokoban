package skeleton;

public interface TestCase {
    public void Test();
    public String GetName();
}
