package server.controller;

public enum ClientState {
    Connected, LoggedIn, Waiting, Playing
}
