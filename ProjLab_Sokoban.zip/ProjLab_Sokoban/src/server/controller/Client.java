package server.controller;

public class Client {
    private ClientState state;

    public Client() {

    }
}
