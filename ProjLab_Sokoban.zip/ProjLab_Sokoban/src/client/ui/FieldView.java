package client.ui;

import common.model.Field;

public class FieldView {
	private Field field;
}
