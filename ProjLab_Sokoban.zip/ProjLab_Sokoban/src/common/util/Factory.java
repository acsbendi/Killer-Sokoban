package common.util;

public interface Factory<T> {
T create();
}
