package common.model;

public class Honey implements Liquid {
	private double friction; //TODO

	@Override
	public double GetFriction() {
		return friction;
	}

}
