package common.model;

import common.util.Direction;

public class Wall extends Field {

	@Override
	public void Check(Direction dir) {

	}

	@Override
	public void Accept(Placeholder obj, Direction dir,Move move) {
		
	}

}
