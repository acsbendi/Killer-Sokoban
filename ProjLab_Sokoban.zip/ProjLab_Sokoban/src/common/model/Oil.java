package common.model;

public class Oil implements Liquid {
	private double friction; //TODO

	@Override
	public double GetFriction() {
		return friction;
	}

}
